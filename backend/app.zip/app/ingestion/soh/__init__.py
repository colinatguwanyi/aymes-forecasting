"""SOH ingestion adapters."""
