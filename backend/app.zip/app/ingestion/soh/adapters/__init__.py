"""SOH format adapters."""
