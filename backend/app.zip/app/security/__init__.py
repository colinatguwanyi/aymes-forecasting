"""Security and auth utilities."""
